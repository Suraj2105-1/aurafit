/**
 * production server entrypoint
 * This file serves as the main entrypoint for production deployments (e.g. Heroku, Render, Glitch)
 * that expect a root-level "server.js" to start the Express application.
 */

// If running in development, we can run TSX directly, otherwise require the compiled bundle
try {
  // Try to load the production compiled bundle
  require('./dist/server.cjs');
} catch (error) {
  if (error.code === 'MODULE_NOT_FOUND') {
    console.warn("Production bundle (dist/server.cjs) not found. Attempting to run via tsx (development)...");
    
    // In development environments, tsx is used to execute server.ts directly
    try {
      require('child_process').spawn('npx', ['tsx', 'server.ts'], {
        stdio: 'inherit',
        shell: true
      });
    } catch (devError) {
      console.error("Failed to start development server. Please run 'npm run dev' or 'npm run build' first.");
      process.exit(1);
    }
  } else {
    console.error("Error launching server:", error);
    process.exit(1);
  }
}
